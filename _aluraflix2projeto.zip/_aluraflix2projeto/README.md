# _Aluraflix2  - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/milhomemboonie/pen/GRBPOyy](https://codepen.io/milhomemboonie/pen/GRBPOyy).

