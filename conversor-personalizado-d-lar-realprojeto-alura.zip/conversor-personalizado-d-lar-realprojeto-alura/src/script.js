var valorEmDolar = 20;
var cotacaoDoDolar = 5.11;

var meuNome = "Bruna";
var valorEmReal = valorEmDolar * cotacaoDoDolar;

alert("Olá, " + meuNome + "! O valor em real é: " + "R$ " + valorEmReal);
