# Conversor PERSONALIZADO (Dólar/Real) - Projeto Alura

A Pen created on CodePen.io. Original URL: [https://codepen.io/milhomemboonie/pen/VwBGzVL](https://codepen.io/milhomemboonie/pen/VwBGzVL).

Instruções:
1. Digite o valor em Dólar que deseja converter na linha 1 do terminal "JS";
2. Digite seu nome na linha 4  do terminal "JS";
3. Clique em "Save";
4. Clique em "Run";