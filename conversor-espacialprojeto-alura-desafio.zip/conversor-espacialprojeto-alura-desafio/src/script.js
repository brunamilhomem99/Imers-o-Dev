var unidadeAstronomica = 13;
var metros = 149597870700;

var resultado = unidadeAstronomica * metros;

alert(resultado + "M");
