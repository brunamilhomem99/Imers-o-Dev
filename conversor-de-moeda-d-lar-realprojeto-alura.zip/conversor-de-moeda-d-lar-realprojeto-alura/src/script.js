var valorEmDolar = 500;
var cotacaoDoDolar = 5.11;

var valorEmReal = valorEmDolar * cotacaoDoDolar;
alert("R$ " + valorEmReal);
