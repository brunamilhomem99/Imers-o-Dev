# Conversor de Moeda (Dólar/Real) - Projeto Alura

A Pen created on CodePen.io. Original URL: [https://codepen.io/milhomemboonie/pen/ExpewyY](https://codepen.io/milhomemboonie/pen/ExpewyY).

Para converter das moedas:
1. Escreva o valor em Dólar que deseja na linha 1 do terminal "JS";
2. Clique em "Save";
3. Clique em "Run";