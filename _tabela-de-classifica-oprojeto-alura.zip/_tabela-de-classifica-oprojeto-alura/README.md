# _Tabela de classificação - Projeto Alura

A Pen created on CodePen.io. Original URL: [https://codepen.io/milhomemboonie/pen/abjXBPX](https://codepen.io/milhomemboonie/pen/abjXBPX).

