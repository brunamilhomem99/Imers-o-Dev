# Jogo Mentalista - Projeto Alura

A Pen created on CodePen.io. Original URL: [https://codepen.io/milhomemboonie/pen/gOjBzrV](https://codepen.io/milhomemboonie/pen/gOjBzrV).

